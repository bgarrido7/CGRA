/**
* MyPyramid
* @constructor
*/
class MyVoxelHill extends CGFobject {
    constructor(scene, altura) {

        super(scene);
        this.altura = altura;
       
        this.Cube = new MyUnitCubeQuad(this.scene, 0.0, 1.0, 1.0, 1.0, 0.0, 0.0, 1.0, 0.0);

    }
    
	//display() {
         
//fazer o Voxell hill, nao consegui fazer, estava com umas ideias mas demasiado cansado para as concretizar
	

  //      }
       

  //  }

}


